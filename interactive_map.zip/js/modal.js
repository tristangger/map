$('.etage01').click(function()
{
    $("#etage01modal").modal();

});

$('.etage02').click(function()
{
    $("#etage02modal").modal();

});


$('.etage03').click(function()
{
    $("#etage03modal").modal();

});




$('[id="hotspot01"]').click(function()
{
    $("#hotspot01modal").modal();

});

$('[id="hotspot02"]').click(function()
{
    $("#hotspot02modal").modal();

});

$('[id="hotspot03"]').click(function()
{
    $("#hotspot03modal").modal();

});

$('[id="hotspot04"]').click(function()
{
    $("#hotspot04modal").modal();

});