var appController = (function(){



var domHandler = {

	checkbox: ".checkbox",
	categoryA: ".dienstleistung",
	categoryB: ".gastronomie",
	categoryC: ".einzelhandel",
	categoryD: ".lebensmittel"


};


var domEvents = {

		checkbox: function(){ $(domHandler.checkbox).on("change", function () {
								console.log("CHECKBOXAAA");
								domEvents.filterCategory();
							})
				},


		filterCategory: function(){
							if ((!$(domHandler.categoryA).prop('checked')) && (!$(domHandler.categoryB).prop('checked')) && (!$(domHandler.categoryC).prop('checked')) && (!$(domHandler.categoryD).prop('checked'))) {

                    			console.log("success");
                    			$('g[id^="map-"]').fadeTo(1000, 0.5);

                			}
                		}
};


var getDataJson= {

	data: function(){
			fetch('./json_mieter.json')
  			.then(
    			function(response) {
     	 			if (response.status !== 200) {
        			console.log('Looks like there was a problem. Status Code: ' +
         			 response.status);
        			return;
     	 			}

      				// Examine the text in the response
     				response.json().then(function(data) {
      		 		 console.log(data);
     				 });
    			}
  		)
  			.catch(function(err) {
    		console.log('Fetch Error :-S', err);
  			});
		}

};








var initApp =function(){
getDataJson.data();
domEvents.checkbox();

};


return initApp;

})();

console.log(appController);
appController(); 